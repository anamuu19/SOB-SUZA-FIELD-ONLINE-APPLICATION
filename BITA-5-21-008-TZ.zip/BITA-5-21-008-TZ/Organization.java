import java.util.Scanner;
public class Organization extends User{
    private String org_stts;
    public Organization(){
        super();
    }
    public Organization(String names, String address, String org_stts){
        super(names,address);
        this.org_stts = org_stts;
    }
    public void setOrgstts(String org_stts){
        this.org_stts = org_stts;
    }
    public String getOrgstts(){
        return org_stts;
    }
    public String toString(){
        return super.toString()+"the organization status is: "+getOrgstts();
    }
    

}