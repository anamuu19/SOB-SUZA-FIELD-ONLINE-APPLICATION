import java.util.Scanner;
public abstract class Student extends User{
    protected String regno;
    private String gender;
    private int age;
    public Student(){
        
    }
    public Student(String names,String address,String regno,String gender,int age){
        super(names,address);
        this.regno = regno;
        this.gender = gender;
        this.age = age;
    }
    
     public Student(String regno,String gender,int age){
        this.regno = regno;
        this.gender = gender;
        this.age = age;
    }
    public abstract void setRegno(String regno);
    public abstract String getRegno();
    public void setGender(String gender){
        this.gender = gender;
    }
    public String getGender(){
        return gender;
    }
     public void setAge(int Age){
        this.age = Age;
    }
    public int getAge(){
        return age;
    }
    public String toString(){
        return super.toString()+" registration no is: "+getRegno()+" gender is: "+getGender()+" age is: "+getAge();
    }
}