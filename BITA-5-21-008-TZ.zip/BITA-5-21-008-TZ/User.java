import java.util.Scanner;
public class User{
    private String names;
    private String address;
    public User(String names,String address){
        this.names = names;
        this.address = address;

    }
    public User(){
        
    }
    public void setNames(String names){
        this.names = names;
    }
    public String getNames(){
        return names;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getAddress(){
        return address;
    }
    public String toString(){
        return "names is: "+getNames()+" and address is: "+getAddress();
    }
    
}