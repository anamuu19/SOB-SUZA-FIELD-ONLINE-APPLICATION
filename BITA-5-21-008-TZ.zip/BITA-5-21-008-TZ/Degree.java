import java.util.Scanner;
public class Degree extends Student{
    private String l_education;
    public Degree(){
        super();
    }
    public Degree(String regno, String gender, int age, String l_education){
        super(regno,gender,age);
        this.l_education = l_education;

    }
     public void setRegno(String regno){
        this.regno = regno;
    }
    public String getRegno(){
        return regno;
    }
    public void setLeveducation(String l_education){
        this.l_education = l_education;
    }
    public String getLeveducation(){
        return l_education;
    }
    @Override
    public String toString(){
        return super.toString()+"the level of education is: "+getLeveducation();
    }
    
}